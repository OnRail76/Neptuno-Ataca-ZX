from PIL import Image, ImageDraw
from pathlib import Path
p=Path(__file__).parent
im=Image.new('1',(64,192)); d=ImageDraw.Draw(im)
a=bytearray([71]*192)
def attr(x,y,w,h,c):
 for j in range(y//8,(y+h)//8):
  for i in range(x//8,(x+w)//8): a[j*8+i]=64+c
font={}
for ch,s in zip('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', ['01110/11011/11011/11111/11011/11011/11011','11110/11011/11011/11110/11011/11011/11110','01111/11000/11000/11000/11000/11000/01111','11110/11011/11011/11011/11011/11011/11110','11111/11000/11000/11110/11000/11000/11111','11111/11000/11000/11110/11000/11000/11000','01111/11000/11000/11011/11011/11011/01111','11011/11011/11011/11111/11011/11011/11011','111/010/010/010/010/010/111','00111/00011/00011/00011/11011/11011/01110','11011/11011/11110/11100/11110/11011/11011','11000/11000/11000/11000/11000/11000/11111','11011/11111/11111/11011/11011/11011/11011','11001/11101/11101/11011/11011/11001/11001','01110/11011/11011/11011/11011/11011/01110','11110/11011/11011/11110/11000/11000/11000','01110/11011/11011/11011/11011/01110/00011','11110/11011/11011/11110/11100/11010/11011','01111/11000/11000/01110/00011/00011/11110','11111/00100/00100/00100/00100/00100/00100','11011/11011/11011/11011/11011/11011/01110','11011/11011/11011/11011/11011/01110/00100','11011/11011/11011/11011/11111/11111/11011','11011/11011/01110/00100/01110/11011/11011','11011/11011/01110/00100/00100/00100/00100','11111/00011/00110/00100/01100/11000/11111','01110/11011/11011/11011/11011/11011/01110','00100/01100/00100/00100/00100/00100/01110','01110/11011/00011/00110/01100/11000/11111','11110/00011/00011/01110/00011/00011/11110','11011/11011/11011/11111/00011/00011/00011','11111/11000/11000/11110/00011/00011/11110','01110/11000/11000/11110/11011/11011/01110','11111/00011/00110/00110/01100/01100/01100','01110/11011/11011/01110/11011/11011/01110','01110/11011/11011/01111/00011/00011/01110']): font[ch]=s.split('/')
def txt(s,y,sy=1,spacing=1):
 widths=[len(font[c][0]) if c!=' ' else 3 for c in s]; x=(64-sum(widths)-spacing*(len(s)-1))//2
 for c,w in zip(s,widths):
  if c!=' ':
   for j,r in enumerate(font[c]):
    for i,v in enumerate(r):
     if v=='1':d.rectangle((x+i,y+j*sy,x+i,y+j*sy+sy-1),fill=1)
  x+=w+spacing
# outer rail separate attribute cells
for y in range(8,184):
 for x in (1,2,61,62): d.point((x,y),fill=1)
for y in range(0,192,8): attr(0,y,8,8,3);attr(56,y,8,8,3)
for y in (0,184):
 attr(0,y,64,8,3);d.line((5,y+3,58,y+3),fill=1,width=2)
# trident
attr(8,8,48,24,6)
d.line((31,10,31,28),fill=1,width=2)
for x in (22,40):
 d.line((x,13,x,20),fill=1,width=2);d.line((x,20,31,24),fill=1,width=2);d.polygon([(x-3,14),(x,9),(x+3,14)],fill=1)
d.polygon([(28,13),(32,7),(35,13)],fill=1)
attr(8,32,48,16,5);txt('NEPTUNO',33,2)
attr(8,48,48,16,2);txt('ATACA',49,2,2)
def divider(y):
 attr(8,y,48,8,5)
 for x in range(8,56,8):d.line((x,y+4,x+3,y+1,x+7,y+4),fill=1,width=2)
divider(64)
attr(8,80,48,8,6);txt('PUNTOS',80)
attr(8,96,48,16,7);txt('000000',96,2,2)
divider(112)
attr(8,128,48,8,6);txt('VIDAS',128)
attr(8,136,48,16,7)
ship=['0001000','0001000','0011100','0010100','0110110','1110111','1101011','0100010']
for x in (13,28,43):
 for j,r in enumerate(ship):
  for i,v in enumerate(r):
   if v=='1':d.point((x+i,140+j),fill=1)
divider(152)
attr(8,168,48,8,6);txt('FASE 1',168)
# export linear panel rows, attributes rows, and full SCR in native ZX ordering
raw=im.tobytes(); (p/'hud_bitmap.bin').write_bytes(raw);(p/'hud_attr.bin').write_bytes(a)
scr=bytearray(6912)
for y in range(192):
 off=((y&192)<<5)|((y&7)<<8)|((y&56)<<2)
 scr[off+24:off+32]=raw[y*8:y*8+8]
for y in range(24):scr[6144+y*32+24:6144+y*32+32]=a[y*8:y*8+8]
(p/'HUD.scr').write_bytes(scr)
colors=[(0,0,0),(0,0,255),(255,0,0),(255,0,255),(0,255,0),(0,255,255),(255,255,0),(255,255,255)]
out=Image.new('RGB',(64,192));
for y in range(192):
 for x in range(64):out.putpixel((x,y),colors[a[y//8*8+x//8]&7] if im.getpixel((x,y)) else (0,0,0))
out.save(p/'HUD.png');out.resize((256,768),Image.Resampling.NEAREST).save(p/'HUD_AMPLIADO.png')
# reconstruct and verify
for y in range(192):
 off=((y&192)<<5)|((y&7)<<8)|((y&56)<<2);assert scr[off+24:off+32]==raw[y*8:y*8+8]
(p/'hud.asm').write_text('hud_bitmap:\n incbin "hud_bitmap.bin"\nhud_attr:\n incbin "hud_attr.bin"\n')
(p/'LEEME.txt').write_text('Panel nativo 64x192. Bitmap lineal: 1536 bytes (8 bytes por scanline), atributos: 192 bytes (8 por fila). HUD.scr: pantalla Spectrum completa con campo izquierdo negro. Colores BRIGHT 1, PAPER negro. Dibujar a columnas 24-31. Puntos, vidas y fase son valores iniciales; actualizar en el motor. No integrado ni probado en emulador.\n')
