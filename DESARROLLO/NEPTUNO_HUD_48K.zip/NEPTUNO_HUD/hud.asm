hud_bitmap:
 incbin "hud_bitmap.bin"
hud_attr:
 incbin "hud_attr.bin"
