from PIL import Image,ImageDraw,ImageFont
import numpy as np
from scipy.ndimage import binary_fill_holes,binary_dilation,label
from pathlib import Path
import json,struct
P=Path(__file__).parent
src=Image.open(P/'referencia_aprobada.png').convert('RGBA'); a=np.array(src); white=(a[:,:,:3].min(2)>175)&(a[:,:,3]>100)
def crop(x,y,z,t,n,span):
 b=white[y:t,x:z]; yy,xx=np.where(b); b=b[yy.min():yy.max()+1,xx.min():xx.max()+1]; h,w=b.shape
 scale=span/max(h,w); W,H=round(w*scale),round(h*scale)
 q=Image.fromarray(b.astype('uint8')*255).resize((W,H),Image.Resampling.BOX); q=np.array(q)>104
 out=np.zeros((n,n),bool); X=(n-W)//2;Y=(n-H)//2;out[Y:Y+H,X:X+W]=q
 return out
D={}
def group(name,n,frames): D[name]=(n,frames)
def blast(n,k):
 im=Image.new('1',(n,n)); d=ImageDraw.Draw(im); c=n//2; r=[3,5,7, min(n//2-1,9)][k]; r=min(r,n//2-2)
 if k<3:
  d.ellipse((c-r,c-r,c+r-1,c+r-1),outline=1,width=2 if k<2 else 1)
  if k==0: d.line((c-1,c-5,c-1,c+4),fill=1);d.line((c-5,c,c+4,c),fill=1)
 for i,(dx,dy) in enumerate([(1,0),(-1,0),(0,1),(0,-1),(1,1),(-1,-1),(-1,1),(1,-1)]):
  rr=min(n//2-1,r+1); x=c+dx*rr;y=c+dy*rr; x=min(n-1,max(0,x));y=min(n-1,max(0,y));d.point((x,y),fill=1)
  if k==1 and 0<x<n-1 and 0<y<n-1:d.point((x-dx,y-dy),fill=1)
 return np.array(im)
def active(row,centers,n,span):
 y,t=row; bounds=[0]+[(x+y)//2 for x,y in zip(centers,centers[1:])]+[1448];return [crop(bounds[i],y,bounds[i+1],t,n,span) for i in range(len(centers))]
def explosions(n):return [(f'destruccion_{i:02}',blast(n,i)) for i in range(4)]
# Use only clean intact reference cells; avoid generated debris and incidental alpha.
dron=active((20,175),[140,320,500,675,840,990],16,14)[:4]
# Stabilize the body and animate only the side emitters and core.
base=dron[0].copy(); dron=[]
for i in range(4):
 b=base.copy()
 if i in (1,3): b[7:9,1:3]=True; b[7:9,13:15]=True
 if i==2: b[7:9,7:9]=True
 dron.append(b)
group('DRON',16,[(f'activo_{i:02}',b) for i,b in enumerate(dron)]+explosions(16))
up=active((190,330),[140,290,450,600],16,14);down=active((340,480),[140,290,450,600],16,14)
# Keep fixed body positions and pulse the engine, rather than resizing the ship per frame.
def engines(base,top):
 out=[]
 for k in range(4):
  b=base.copy(); y=0 if top else 15
  if k in (1,3): b[y,7:9]=True
  if k==2: b[y,7:9]=True; b[1 if top else 14,6:10]=True
  out.append(b)
 return out
up=engines(up[0],False); down=engines(down[0],True)
group('NAVE_VERTICAL',16,[(f'{s}_{i:02}',b) for s,ls in [('arriba',up),('abajo',down)] for i,b in enumerate(ls)]+explosions(16))
sold=active((500,650),[115,295,460,640,810,980,1150,1330],16,14)
group('SOLDADO',16,[(f'apuntado_{s}_00',b) for s,b in zip(['N','NE','E','SE','S','SW','W','NW'],sold)]+explosions(16))
# Tank drawn at native resolution: fixed central LED, no rotating cannon; hull rotated as a whole.
im=Image.new('1',(24,24));d=ImageDraw.Draw(im);d.rounded_rectangle((3,2,20,21),radius=3,fill=1);d.rectangle((7,3,16,20),fill=0);d.rounded_rectangle((8,5,15,17),radius=2,fill=1);d.rectangle((10,9,13,13),fill=0);d.rectangle((11,10,12,12),fill=1);d.line((9,7,14,7),fill=0);d.line((9,15,14,15),fill=0)
for y in range(5,21,4):d.line((3,y,6,y),fill=0);d.line((17,y,20,y),fill=0)
d.line((9,3,14,3),fill=1);d.line((10,4,13,4),fill=1)
tank=np.array(im); tf=[]
for j,s in enumerate(['N','E','S','W']):
 for i in range(2):
  b=tank.copy()
  if i:b[10:13,11:13]=False
  tf.append((f'{s}_{i:02}',np.rot90(b,-j)))
group('TANQUE_SIRIA',24,tf+explosions(24))
tur=active((910,1060),[140,315,485,655,825,990,1160],24,20)[:4]
base=tur[0].copy();tur=[]
for i in range(4):
 b=base.copy()
 if i in (1,3): b[11:13,11:13]=True
 if i==2:b[10:14,10:14]=True
 tur.append(b)
group('TORRETA',24,[(f'activo_{i:02}',b) for i,b in enumerate(tur)]+explosions(24))
def pack(b):return np.packbits(b,axis=1,bitorder='big').tobytes()
manifest={}; preview=Image.new('RGB',(720,5*116+25),'#161616');draw=ImageDraw.Draw(preview);font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',14)
for row,(name,(n,frames)) in enumerate(D.items()):
 folder=P/name;folder.mkdir(exist_ok=True);(folder/'PNG').mkdir(exist_ok=True);(folder/'MASK').mkdir(exist_ok=True)
 pixels=bytearray(); masks=bytearray(); tiledata=bytearray(); asm=[]; offsets={}; sheet=Image.new('RGBA',(n*len(frames),n));
 for i,(key,b) in enumerate(frames):
  # Keep opaque black internal holes and one-pixel black outline, except free debris.
  opaque=binary_dilation(binary_fill_holes(b),iterations=1) if not key.startswith('destruccion') else b.copy(); m=~opaque
  raw=pack(b); mr=pack(m); assert not any(x&y for x,y in zip(raw,mr)); assert np.array_equal(np.unpackbits(np.frombuffer(raw,dtype=np.uint8)).reshape(n,n),b)
  rgba=np.zeros((n,n,4),dtype=np.uint8);rgba[:,:,:3]=b[:,:,None]*255;rgba[:,:,3]=opaque*255; img=Image.fromarray(rgba);img.save(folder/'PNG'/f'{key}.png');Image.fromarray(m.astype('uint8')*255).save(folder/'MASK'/f'{key}.png');sheet.paste(img,(i*n,0));offsets[key]=len(pixels);pixels+=raw;masks+=mr
  asm.append(f'{name.lower()}_{key}:\n db '+','.join(f'${v:02X}' for v in raw)+'\n'+f'{name.lower()}_{key}_mask:\n db '+','.join(f'${v:02X}' for v in mr))
  for yy in range(0,n,8):
   for xx in range(0,n,8):tiledata+=pack(m[yy:yy+8,xx:xx+8])+pack(b[yy:yy+8,xx:xx+8])
  scale=2; x=10+i*58;y=32+row*116; bg=Image.new('RGBA',(n,n),'black');bg.alpha_composite(img);preview.paste(bg.convert('RGB').resize((n*scale,n*scale),Image.Resampling.NEAREST),(x,y));draw.text((x,y+51),str(i+1),font=font,fill='#aaaaaa')
 sheet.save(folder/'SHEET_ZX.png');(folder/'frames_lineales.bin').write_bytes(pixels);(folder/'mascaras_lineales.bin').write_bytes(masks);(folder/'sprites_tiles_16bytes.bin').write_bytes(tiledata);(folder/'sprites.asm').write_text('\n\n'.join(asm)+'\n');manifest[name]={'width':n,'height':n,'frame_bytes':n*n//8,'frames':list(offsets),'offsets':offsets,'bitmap_bytes':len(pixels),'mask_bytes':len(masks)};draw.text((10,row*116+8),f'{name}  |  {n} x {n}  |  {len(frames)} frames',font=font,fill='white')
(P/'manifest.json').write_text(json.dumps(manifest,indent=2));preview.save(P/'PREVIEW.png');print(sum(len(v[1]) for v in D.values()),sum(v['bitmap_bytes']+v['mask_bytes'] for v in manifest.values()))
