; Cargar una pantalla a $4000 (6912 bytes), desde memoria o cinta.
; HL = origen, preservacion de registros a cargo del llamador.
mostrar_scr:
 ld de,$4000
 ld bc,6912
 ldir
 ret
; Espera minima 150 interrupciones PAL (3 segundos), IM1 y EI activos.
espera_3s:
 ld b,150
.loop:
 halt
 djnz .loop
 ret
; Despues: esperar liberacion y nueva pulsacion de SPACE o FIRE.
