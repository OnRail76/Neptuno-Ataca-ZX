from PIL import Image, ImageDraw
from pathlib import Path
import random
p=Path(__file__).parent
# Font: explicit native 5x7 bitmap, same design language as HUD.
chars='ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
patterns=['01110/11011/11011/11111/11011/11011/11011','11110/11011/11011/11110/11011/11011/11110','01111/11000/11000/11000/11000/11000/01111','11110/11011/11011/11011/11011/11011/11110','11111/11000/11000/11110/11000/11000/11111','11111/11000/11000/11110/11000/11000/11000','01111/11000/11000/11011/11011/11011/01111','11011/11011/11011/11111/11011/11011/11011','111/010/010/010/010/010/111','00111/00011/00011/00011/11011/11011/01110','11011/11011/11110/11100/11110/11011/11011','11000/11000/11000/11000/11000/11000/11111','11011/11111/11111/11011/11011/11011/11011','11001/11101/11101/11011/11011/11001/11001','01110/11011/11011/11011/11011/11011/01110','11110/11011/11011/11110/11000/11000/11000','01110/11011/11011/11011/11011/01110/00011','11110/11011/11011/11110/11100/11010/11011','01111/11000/11000/01110/00011/00011/11110','11111/00100/00100/00100/00100/00100/00100','11011/11011/11011/11011/11011/11011/01110','11011/11011/11011/11011/11011/01110/00100','11011/11011/11011/11011/11111/11111/11011','11011/11011/01110/00100/01110/11011/11011','11011/11011/01110/00100/00100/00100/00100','11111/00011/00110/00100/01100/11000/11111','01110/11011/11011/11011/11011/11011/01110','00100/01100/00100/00100/00100/00100/01110','01110/11011/00011/00110/01100/11000/11111','11110/00011/00011/01110/00011/00011/11110','11011/11011/11011/11111/00011/00011/00011','11111/11000/11000/11110/00011/00011/11110','01110/11000/11000/11110/11011/11011/01110','11111/00011/00110/00110/01100/01100/01100','01110/11011/11011/01110/11011/11011/01110','01110/11011/11011/01111/00011/00011/01110']
font={c:s.split('/') for c,s in zip(chars,patterns)}
font['.']=['0']*6+['1'];font['/']=['00001','00010','00010','00100','01000','01000','10000'];font['-']=['000','000','000','111','000','000','000']
colors=[(0,0,0),(0,0,255),(255,0,0),(255,0,255),(0,255,0),(0,255,255),(255,255,0),(255,255,255)]
def init():
 global im,d,a
 im=Image.new('1',(256,192));d=ImageDraw.Draw(im);a=bytearray([71]*768)
def attr(x,y,w,h,c,bright=True):
 assert x%8==y%8==w%8==h%8==0
 for j in range(y//8,(y+h)//8):
  for i in range(x//8,(x+w)//8):a[j*32+i]=c+64*bright
def txt(s,y,sx=1,sy=1,spacing=1,slant=False):
 widths=[len(font[c][0])*sx if c!=' ' else 3*sx for c in s];x=(256-sum(widths)-spacing*(len(s)-1)-(3 if slant else 0))//2
 for c,w in zip(s,widths):
  if c!=' ':
   for j,r in enumerate(font[c]):
    for i,v in enumerate(r):
     if v=='1':
      xx=x+i*sx+((6-j)//2 if slant else 0);d.rectangle((xx,y+j*sy,xx+sx-1,y+j*sy+sy-1),fill=1)
  x+=w+spacing
def frame():
 for x in (0,248):attr(x,0,8,192,3);d.line((x+3,8,x+3,183),fill=1,width=2)
 for y in (0,184):attr(0,y,256,8,3);d.line((8,y+3,247,y+3),fill=1,width=2)
 for x in (8,232):
  for y in (8,176):attr(x,y,16,8,5);d.line((x,y+3,x+15,y+3),fill=1,width=2)
def waves(y):
 attr(24,y,208,8,5)
 for x in range(24,232,16):d.line((x,y+5,x+4,y+1,x+8,y+5,x+12,y+1,x+15,y+4),fill=1,width=1)
def trident(cx,y):
 d.line((cx,y+3,cx,y+37),fill=1,width=3)
 for x in (cx-19,cx+19):
  d.line((x,y+10,x,y+21),fill=1,width=3);d.line((x,y+21,cx,y+29),fill=1,width=3);d.polygon([(x-5,y+11),(x,y+3),(x+5,y+11)],fill=1)
 d.polygon([(cx-5,y+9),(cx,y),(cx+5,y+9)],fill=1)
def export(name):
 scr=bytearray(6912);raw=im.tobytes()
 for y in range(192):
  off=((y&192)<<5)|((y&7)<<8)|((y&56)<<2);scr[off:off+32]=raw[y*32:y*32+32]
 scr[6144:]=a;(p/(name+'.scr')).write_bytes(scr)
 # Decode actual SCR, not source canvas.
 out=Image.new('RGB',(256,192))
 for y in range(192):
  off=((y&192)<<5)|((y&7)<<8)|((y&56)<<2)
  for x in range(256):
   at=scr[6144+y//8*32+x//8];bit=(scr[off+x//8]>>(7-x%8))&1
   c=colors[(at&7) if bit else ((at>>3)&7)];out.putpixel((x,y),c if at&64 else tuple(v*205//255 for v in c))
 assert len(scr)==6912
 out.save(p/(name+'.png'));out.resize((768,576),Image.Resampling.NEAREST).save(p/(name+'_3X.png'))
 return out
# TITLE: trident emblem, oversized two-line wordmark, clear controls.
init();frame();attr(88,8,80,40,6);trident(128,9)
attr(16,48,224,32,5);txt('NEPTUNO',48,4,4,4,True)
attr(16,80,224,32,2);txt('ATACA',80,5,4,5,True);waves(112)
attr(16,128,224,8,7);txt('Q A O P / SPACE',128,2,1,2)
attr(16,144,224,8,5);txt('KEMPSTON',144,1,1,2)
attr(16,160,224,8,6);txt('PULSA FUEGO',160,2,1,2)
attr(16,176,224,8,7);txt('2026 TONY C. WARE',176,1,1,1)
title=export('TITULO')
# GAME OVER: broken trident and arcade typography.
init();frame();attr(24,16,208,48,2)
d.line((128,20,128,34),fill=1,width=3);d.line((109,24,109,36,123,42),fill=1,width=3);d.line((147,24,147,36,135,42),fill=1,width=3)
for x in (109,128,147):d.polygon([(x-5,25),(x,17),(x+5,25)],fill=1)
d.line((133,46,124,53,130,62),fill=1,width=3)
for x,y in [(105,48),(150,44),(115,58),(143,59),(96,36),(160,36)]:d.rectangle((x,y,x+2,y+2),fill=1)
attr(16,72,224,32,2);txt('GAME',72,5,4,5,True)
attr(16,104,224,32,7);txt('OVER',104,5,4,5,True)
waves(144);attr(16,160,224,8,6);txt('PULSA FUEGO',160,2,1,2)
over=export('GAME_OVER')
# VICTORY: stylized Barcelona skyline / sunset, strictly native attributes.
init();frame();attr(16,16,224,24,6);txt('VICTORIA',16,4,3,3,True)
attr(16,48,224,8,7);txt('LA TIERRA ES LIBRE',48,1,1,2)
# setting sun and horizontal sky bands, no mixed colors per cell
attr(16,64,224,40,2);d.ellipse((96,65,159,128),fill=1)
for y in (79,87,95,103):d.line((16,y,239,y),fill=0,width=2)
# clear lower city band and draw silhouetted roofline in white
for y in range(104,144):d.line((16,y,239,y),fill=0)
attr(16,104,224,40,7)
# skyline outlines and towers: Sagrada Familia inspired, not a literal scale model
for x,w,h in [(18,18,12),(39,22,20),(65,13,10),(82,18,17),(162,18,19),(184,21,12),(209,26,21)]:
 y=142-h;d.line((x,142,x,y,x+w,y,x+w,142),fill=1,width=2)
 for xx in range(x+4,x+w-2,5):d.point((xx,y+5),fill=1)
for x,h in [(108,23),(117,35),(126,29),(135,35),(144,23)]:
 y=142-h;d.line((x-3,142,x-3,y+5,x,y,x+3,y+5,x+3,142),fill=1,width=1);d.line((x,y+8,x,y+16),fill=1)
d.line((16,143,239,143),fill=1)
waves(144);attr(16,160,224,8,6);txt('THE END',160,2,1,3)
attr(16,176,224,8,7);txt('PULSA FUEGO',176,1,1,2)
win=export('VICTORIA')
# Side-by-side native screenshots decoded from files.
atlas=Image.new('RGB',(768,192));
for i,im2 in enumerate((title,over,win)):atlas.paste(im2,(i*256,0))
atlas.resize((1536,384),Image.Resampling.NEAREST).save(p/'ATLAS.png')
(p/'pantallas.asm').write_text('; Cargar una pantalla a $4000 (6912 bytes), desde memoria o cinta.\n; HL = origen, preservacion de registros a cargo del llamador.\nmostrar_scr:\n ld de,$4000\n ld bc,6912\n ldir\n ret\n; Espera minima 150 interrupciones PAL (3 segundos), IM1 y EI activos.\nespera_3s:\n ld b,150\n.loop:\n halt\n djnz .loop\n ret\n; Despues: esperar liberacion y nueva pulsacion de SPACE o FIRE.\n')
(p/'LEEME.txt').write_text('NEPTUNO ATACA - Pantallas ZX Spectrum 48K\nTres SCR nativas 256x192, 6912 bytes cada una (6144 bitmap + 768 atributos). PNG decodificados de los SCR. Estilo del HUD, tipografia bitmap. Victoria: interpretacion estilizada de Barcelona, no captura del juego. Textos propuestos. ASM auxiliar sin ensamblar; integrar lectura de FIRE/SPACE y multicarga en el motor. No se ha probado en emulador. Para evitar mantener 20736 bytes residentes, cargar solo la pantalla necesaria o comprimirla con el descompresor definitivo. GAME OVER y VICTORIA: bloquear retorno al titulo durante 150 interrupciones PAL, despues esperar liberacion y nueva pulsacion.\n')
